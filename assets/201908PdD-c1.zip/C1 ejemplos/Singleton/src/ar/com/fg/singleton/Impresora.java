/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.singleton;
import java.time.LocalDateTime;

/**
 *
 * @author Federico
 */
public class Impresora {
    
    private static Impresora instance;    
    private String creacion;
    
    private Impresora() {   
        
        creacion = LocalDateTime.now().toString();
    }
    
    public static Impresora getInstance() {
        if (instance == null) {
            instance = new Impresora();
        }

        return instance;
    }
    
    public void imprimir(String texto) {
        System.out.println("Impresora creada el " + creacion);
        System.out.println("Imprimiendo: " + texto);
    }
    
}
