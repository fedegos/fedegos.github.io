/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.builder.actores;

import java.util.List;

/**
 *
 * @author Federico
 */
public class Sandwich {
          
    private TipoDePan tipoDePan;
    private TipoDeQueso tipoDeQueso;
    private TipoDeCarne tipoDeCarne;
    private boolean esTostado;
    private boolean tieneMostaza;    
    private boolean tieneMayonesa;
    private List<String> vegetales;
    
    
    public void Mostrar() {
        System.out.println("Sandwich en pan de " + this.tipoDePan);
        
        if (this.esTostado) {
            System.out.println("Tostado");
        }
        
        if (this.tieneMayonesa) {
            System.out.println("Con mayonesa");
        }
        
        if (this.tieneMostaza) {
            System.out.println("Con mostaza");
        }
        
        System.out.println(String.format("Carne: %s", this.tipoDeCarne));
        System.out.println(String.format("Queso: %s", this.tipoDeQueso));
        System.out.println("Vegetales:");
        for (String vegetal : this.vegetales) {
            System.out.println(" + " + vegetal);
        }        
    }

    /**
     * @param tipoDePan the tipoDePan to set
     */
    public void setTipoDePan(TipoDePan tipoDePan) {
        this.tipoDePan = tipoDePan;
    }

    /**
     * @param tipoDeQueso the tipoDeQueso to set
     */
    public void setTipoDeQueso(TipoDeQueso tipoDeQueso) {
        this.tipoDeQueso = tipoDeQueso;
    }

    /**
     * @param tipoDeCarne the tipoDeCarne to set
     */
    public void setTipoDeCarne(TipoDeCarne tipoDeCarne) {
        this.tipoDeCarne = tipoDeCarne;
    }

    /**
     * @param esTostado the esTostado to set
     */
    public void setEsTostado(boolean esTostado) {
        this.esTostado = esTostado;
    }

    /**
     * @param tieneMostaza the tieneMostaza to set
     */
    public void setTieneMostaza(boolean tieneMostaza) {
        this.tieneMostaza = tieneMostaza;
    }

    /**
     * @param tieneMayonesa the tieneMayonesa to set
     */
    public void setTieneMayonesa(boolean tieneMayonesa) {
        this.tieneMayonesa = tieneMayonesa;
    }

    /**
     * @param vegetales the vegetales to set
     */
    public void setVegetales(List<String> vegetales) {
        this.vegetales = vegetales;
    }
       
    
}
