/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.builder.actores;

/**
 *
 * @author Federico
 */
public class SandwichMaker {
    
    private SandwichBuilder builder;
    
    public SandwichMaker(SandwichBuilder builder) {
        this.builder = builder;
    }
    
    public void BuildSanwdich() {
        builder.CreateNewSandwich();
        builder.PrepararPan();
        builder.AplicarCarneYQueso();
        builder.AplicarVegetales();
        builder.AgregarCondimentos();      
    }
    
    public Sandwich GetSandwich() {
        return builder.GetSandwich();
    }
    
}
