/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.builder.builders;

import ar.com.fg.builder.actores.SandwichBuilder;
import ar.com.fg.builder.actores.TipoDeCarne;
import ar.com.fg.builder.actores.TipoDePan;
import ar.com.fg.builder.actores.TipoDeQueso;
import java.util.Arrays;

/**
 *
 * @author Federico
 */
public class BondiolaYFiladelfiaBuilder extends SandwichBuilder {

    @Override
    public void PrepararPan() {
        this.sandwich.setTipoDePan(TipoDePan.PEBETE);
        this.sandwich.setEsTostado(false);
    }

    @Override
    public void AplicarCarneYQueso() {
        this.sandwich.setTipoDeCarne(TipoDeCarne.BONDIOLA);
        this.sandwich.setTipoDeQueso(TipoDeQueso.FILADELFIA);
    }

    @Override
    public void AplicarVegetales() {
        this.sandwich.setVegetales(Arrays.asList("Repollo", "Cebolla colorada", "Zanahoria"));        
    }

    @Override
    public void AgregarCondimentos() {
        this.sandwich.setTieneMayonesa(false);
        this.sandwich.setTieneMostaza(true);
    }
    
}
