/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.prototype.main;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Federico
 */
public class WebScraper implements Cloneable {
    
    private String titulo;
    private String cuentaCabeceras;
    private String primerCabecera;
    private String url;
    
    public WebScraper(String url) {
        System.out.println("Creando Scraper...");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(WebScraper.class.getName()).log(Level.SEVERE, null, ex);
        }                
        this.url = url;
        this.titulo = "Mi tíutlo";
        this.cuentaCabeceras = "5";
        this.primerCabecera = "Primer post";
    }
    
    public void mostrarDatosDePagina() {
        System.out.println("URL: " + url );
        System.out.println("Título: " + titulo );
        System.out.println("Número de cabeceras: " + cuentaCabeceras );
        System.out.println("Primer Cabecera: " + primerCabecera);
        
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
    
}
