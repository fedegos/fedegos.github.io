/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.prototype.main;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws CloneNotSupportedException {
        
        WebScraper scraper = new WebScraper("www.google.com");
        scraper.mostrarDatosDePagina();
        
        // WebScraper scraper2 = new WebScraper("www.google.com");
        // scraper2.mostrarDatosDePagina();
        
        WebScraper scraper3 = (WebScraper)scraper.clone();
        
        scraper3.mostrarDatosDePagina();

        
        

        /*
        WebScraper scraper2 = new WebScraper("www.google.com");
        scraper2.mostrarDatosDePagina();
        */ 
        /*
        WebScraper scraper3 = (WebScraper)scraper.clone();
        scraper3.mostrarDatosDePagina();
        */

    }
    
}
