package ar.com.educacionit.patrones.interfaces;

public interface Vendible {
    public String getDescripcion();

    public int getPrecio();
}
