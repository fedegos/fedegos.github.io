package ar.com.educacionit.patrones.actores;

import ar.com.educacionit.patrones.interfaces.Vendible;

public abstract class Auto implements Vendible {
}
