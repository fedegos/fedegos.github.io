/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.educacionit.patrones.decoradores;

import ar.com.educacionit.patrones.interfaces.Vendible;

/**
 *
 * @author Federico
 */
public class ClimatizadorBizona extends AutoDecorator {
    
    public ClimatizadorBizona(Vendible vendible) {
        super(vendible);
    }
    
    @Override
    public String getDescripcion() {
        return getVendible().getDescripcion() + " + Climatizador Bizona";        
    }

    @Override
    public int getPrecio() {
        return getVendible().getPrecio() + 5000;        
    }
    
}
