/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.educacionit.patrones.actores;

/**
 *
 * @author Federico
 */
public class AudiTt extends Auto {
       
    @Override
    public String getDescripcion() {
        return "Audi TT 2018";
    }

    @Override
    public int getPrecio() {
        return 35000;
    }
    
}
