/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.implementadoresconcretos;

import ar.com.fg.implementador.Tema;

/**
 *
 * @author Federico
 */
public class TemaOscuro implements Tema {

    @Override
    public void dibujarTitulo() {
        System.out.println("Dibujando título oscuro");
    }

    @Override
    public void dibujarBoton() {
        System.out.println("Dibujando botón oscuro");
    }

    @Override
    public void dibujarTabla() {
        System.out.println("Dibujando tabla oscura");
    }

    @Override
    public void dibujarParrafo() {
        System.out.println("Dibujando párrafo oscuro");
    }

    @Override
    public void dibujarGaleria() {
        System.out.println("Dibujando galería oscura");
    }

    @Override
    public void insertarImagen() {
        System.out.println("Insertando imagen con marco oscuro");
    }
    
}
