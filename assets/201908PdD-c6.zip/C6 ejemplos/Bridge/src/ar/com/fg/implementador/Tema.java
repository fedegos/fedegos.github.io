/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.implementador;

/**
 *
 * @author Federico
 */
public interface Tema {
    
    public void dibujarTitulo();
    public void dibujarBoton();
    public void dibujarTabla();
    public void dibujarParrafo();
    public void dibujarGaleria();
    public void insertarImagen();
    
}
