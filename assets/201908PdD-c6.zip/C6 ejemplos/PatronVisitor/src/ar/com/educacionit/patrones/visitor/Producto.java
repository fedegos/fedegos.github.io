package ar.com.educacionit.patrones.visitor;

public abstract class Producto {
    
    protected double precio;
    
    public abstract double accept(ProductoVisitor visitor);
    
    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
