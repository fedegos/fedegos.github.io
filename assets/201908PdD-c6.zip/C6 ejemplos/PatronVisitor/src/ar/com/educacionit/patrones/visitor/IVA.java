package ar.com.educacionit.patrones.visitor;

public class IVA implements ProductoVisitor {
    private final double impuestoNormal = 1.21;
    private final double impuestoReducido = 1.105;

    @Override
    public double visit(ProductoNormal normal) {
        return normal.getPrecioNormal() * impuestoNormal;
    }

    @Override
    public double visit(ProductoDescuento reducido) {
        return reducido.getPrecio() * impuestoReducido;
    }

    @Override
    public double visit(ProductoExento exento) {
        return exento.precio();
    }
}
