package ar.com.educacionit.patrones.visitor;

public interface ProductoVisitor {
    public double visit(ProductoNormal normal);

    public double visit(ProductoDescuento reducido);
    
    public double visit(ProductoExento exento);
}
