/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.educacionit.patrones.visitor;

/**
 *
 * @author EducaciónIT
 */
public class ProductoExento extends Producto {

    @Override
    public double accept(ProductoVisitor visitor) {
        return visitor.visit(this);
    }
    
    public double precio() {
        return 200;
    }
    
}
