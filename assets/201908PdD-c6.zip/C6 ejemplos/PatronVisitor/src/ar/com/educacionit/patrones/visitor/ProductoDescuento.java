package ar.com.educacionit.patrones.visitor;

public class ProductoDescuento extends Producto {
    private double precio;

    @Override
    public double accept(ProductoVisitor visitor) {
        return visitor.visit(this);
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
