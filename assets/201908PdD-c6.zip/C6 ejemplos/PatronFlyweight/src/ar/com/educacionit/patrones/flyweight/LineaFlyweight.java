package ar.com.educacionit.patrones.flyweight;

public interface LineaFlyweight {
    public String getColor();
    public void dibujar(int col, int fila);
}
