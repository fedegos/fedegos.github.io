
// definir a una función
function nombreDeLaFuncion(parametros) {
	// bloque de código
	return resultado;	
}

// Invocar a una función
nombreDeLaFuncion(parametrosDeEntrada)

// Asignar el resultado de una función a una variable
var variable = miFuncion();

function mostrarItems(item) {
	console.log(item.name);
	console.log(item.drilling);
}

data.groups.forEach(mostrarItems);