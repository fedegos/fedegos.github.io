// Dos maneras de crear una expresión regular:

const expReg1 = /abc/;

const expReg2 = new RegExp("abc");

/*
Los componentes de las expresiones regulares se dividen en dos tipos:

1. Literales

2. Metacaractéres

Hay tres grupos de metacaractéres:

2.1 Caracter simple

\d      Coincide con un caracter numérico (0-9)
\D      Coincide con un caracter NO numérico
\s      Coincide con un espacio entre los que se encuentran los saltos de página,
        tabulaciones y saltos de línea
\S      Coincide con todo menos un espacio
\t      Coincide con una tabulación
\w      Coincide con cualquier alfanumérico incluyendo el guión bajo
\W      Coincide con cualquier caracter que NO sea alfanumérico

2.1 Cuantificadores

*       Coincide con 0 o más repeticiones
+       Coincide con 1 o más repeticiones
?       Coincide con 0 o 1 repetición
{N}     Coincide con N repeticiones
{N,M}   Coincide con repeticiones de como mínimo N y máximo M
[LMN]   Coincide con el caracter L, M o N
[a-Z]   Coincide con un caracter entre la a y la z, por charcode (a = 97, z = 122).

2.3 Posicionadores

^       Coincide con el princípio del string
$       Coincide con el final del string
\b      Coincide con el límite de un string


*/

const cadena = "hola mundo!";

expReg1.test("cadena");

cadena.match(expReg1);

cadena.replace(expReg1, cadenaNueva); // se puede usar una función para determinar el reemplazo.