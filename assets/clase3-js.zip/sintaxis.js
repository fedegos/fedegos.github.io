// Arreglos
var lista = [];

var empleados = ["Juan", "Pedro", "Gabriela", "Adriana"];

var alumnos = new Array("Juan", "Pedro");

var pares = [2];
var pares = new Array(2); // = [ undefined, undefined] 

alert(alumnos[0]);

// leer cuántos elementos tiene un arreglo
alert(alumnos.length);

// Objetos

var objeto = { 
	propiedad1: "valor", 
	propiedad2: "otro valor"
};

var empleado = {
	nombre: "Federico",
	apellido: "Gosman"
};

// la forma más común de acceder a una propiedad:
alert(empleado.nombre);
empleado.nombre = "Federico H.";

// otra forma de acceder:
alert(empleado["nombre"]);
empleado["nombre"] = "Federico";

// arreglos y objetos

var empleados = [
	{ nombre: "Juan", apellido: "Perez" },
	{ nombre: "Pedro", apellido: "Gomez"}
];

// ordenar 

arreglo.sort();

// agregar un elemento al final del arreglo

arreglo.push(elementoNuevo);

// quitar un elemento del final del arreglo

var elementoQuitado = arreglo.pop();

// agregar un elemento al principio de la lista

arreglo.unshift(nuevoElemento);

// quitar el primer elemento de la lista

var elementoQuitadoDelPrincipio = arreglo.shift();

// sacar y agregar elementos en medio del arreglo

// eliminar elemento en la posición del índice
arreglo.splice(indice) // 0 a length - 1

// eliminar 3 elementos de la posición del índice
arreglo.splice(indice, cantidadDeElementosABorrar); // 0 a length - 1
arreglo.splice(2, 3);

// eliminar e insertar nuevos elementos en esa posición
arreglo.splice(indice, cantidad, nuevoElemento1, nuevoElemento2... etc);
arreglo.splice(2, 1, "A");

// insertar sin borrar
arreglo.splice(2, 0, "A");

// concatenar
var empresa = sectorA.concat(sectorB);

// slice
var subConjunto = conjunto.slice(3); // arreglo desde la posición 3 de conjunto en adelante


// Bucles

for (pasoInicial; condicion; pasoIncremental){
	bloqueDeCodigo;
}

for (var i=0; i < 2; i++) {
	console.log(i);
}

while (condicion) {
	bloque
}

do {
	bloque
} while (condicion)

// saltar un ciclo
for () {
	if (condicion) continue;
	
	// se ejecuta el ciclo
}

// para salirme del bucle
for (...) {	
	if (condicion) break;

}