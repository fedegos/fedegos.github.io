package ar.com.educacionit.patrones.proxy;

import java.util.List;

public interface IGuardar {
    public void save(List datosAGuardar);
}
