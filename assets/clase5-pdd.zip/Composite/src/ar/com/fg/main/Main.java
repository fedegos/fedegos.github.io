/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.actores.CentralElectrica;
import ar.com.fg.actores.LineaAltaTension;
import ar.com.fg.actores.RedDistribucionUrbana;
import ar.com.fg.actores.UsuarioFinalElectricidad;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        CentralElectrica belgrano = new CentralElectrica();
        
        LineaAltaTension belgranoARosario = new LineaAltaTension();
        LineaAltaTension belgranoABsAs = new LineaAltaTension();
        
        belgrano.agregarComponente(belgranoABsAs);
        belgrano.agregarComponente(belgranoARosario);
        
        RedDistribucionUrbana rosarioSur = new RedDistribucionUrbana();
        belgranoARosario.agregarComponente(rosarioSur);
        
        RedDistribucionUrbana ambaNorte = new RedDistribucionUrbana();
        RedDistribucionUrbana ambaSur = new RedDistribucionUrbana();
        belgranoABsAs.agregarComponente(ambaNorte);
        belgranoABsAs.agregarComponente(ambaSur);
        
        rosarioSur.agregarComponente(new UsuarioFinalElectricidad());
        rosarioSur.agregarComponente(new UsuarioFinalElectricidad());
        rosarioSur.agregarComponente(new UsuarioFinalElectricidad());
        
        ambaNorte.agregarComponente(new UsuarioFinalElectricidad());
        ambaNorte.agregarComponente(new UsuarioFinalElectricidad());
        ambaNorte.agregarComponente(new UsuarioFinalElectricidad());
        ambaNorte.agregarComponente(new UsuarioFinalElectricidad());
        ambaNorte.agregarComponente(new UsuarioFinalElectricidad());
        
        ambaSur.agregarComponente(new UsuarioFinalElectricidad());
        ambaSur.agregarComponente(new UsuarioFinalElectricidad());
        
        belgrano.desconectar();        
        ambaSur.conectar();                  
        
    }
    
}
