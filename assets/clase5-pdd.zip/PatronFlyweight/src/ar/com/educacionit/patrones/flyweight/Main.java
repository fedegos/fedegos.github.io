package ar.com.educacionit.patrones.flyweight;

public class Main {

    public static void main(String[] args) {
        LineaFactory fabrica = new LineaFactory();

        LineaFlyweight linea1 = fabrica.getLine("AZUL");
        LineaFlyweight linea2 = fabrica.getLine("ROJO");
        LineaFlyweight linea3 = fabrica.getLine("AMARILLO");
        LineaFlyweight linea4 = fabrica.getLine("AZUL");

        System.out.println("-------------------");

        //can use the lines independently
        linea1.dibujar(100, 400);
        linea2.dibujar(200, 500);
        linea3.dibujar(300, 600);
        linea4.dibujar(400, 700);
    }
}
