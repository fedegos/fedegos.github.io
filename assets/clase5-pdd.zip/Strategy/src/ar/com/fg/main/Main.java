/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.contexto.Catalogo;
import ar.com.fg.contexto.Producto;
import ar.com.fg.estrategias.DiaDeLaMadre;
import ar.com.fg.estrategias.EstrategiaPrecios;
import ar.com.fg.estrategias.HotSale;
import ar.com.fg.estrategias.PreciosLista;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Vamos a agregar una estrategia: día de las madres.
        
        EstrategiaPrecios estrategia = new PreciosLista();
        Catalogo catalogo = new Catalogo(estrategia);
        
        catalogo.agregarProducto(new Producto("TV Sony 42", 20000));        
        catalogo.agregarProducto(new Producto("TV Samsung 50", 26000));
        catalogo.agregarProducto(new Producto("MacBook", 46000));
        catalogo.agregarProducto(new Producto("Cafetera Expreso", 5400));
        
        catalogo.mostrarCatalogo();
        
        System.out.println("*******************************");
        
        catalogo.setEstrategia(new HotSale());
        
        catalogo.mostrarCatalogo();
        
        System.out.println("*******************************");
        
        catalogo.setEstrategia(new DiaDeLaMadre());
        
        catalogo.mostrarCatalogo();        
        
    }
    
}
