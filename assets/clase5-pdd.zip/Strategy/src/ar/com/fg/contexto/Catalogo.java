/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.contexto;

import ar.com.fg.estrategias.EstrategiaPrecios;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Federico
 */
public class Catalogo {

    private EstrategiaPrecios estrategia;
    private List<Producto> productos = new ArrayList<>();

    public Catalogo(EstrategiaPrecios estrategia) {
        this.estrategia = estrategia;
    }

    /**
     * @param estrategia the estrategia to set
     */
    public void setEstrategia(EstrategiaPrecios estrategia) {
        this.estrategia = estrategia;
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void mostrarCatalogo() {
        for (Producto producto : productos) {
            System.out.println(
                    producto.getNombre()
                    + ": "
                    + String.valueOf(
                            estrategia.calcularPrecio(producto)
                    )
            );
        }
    }

}
