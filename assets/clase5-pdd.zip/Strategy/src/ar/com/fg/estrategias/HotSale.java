/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.estrategias;

import ar.com.fg.contexto.Producto;

/**
 *
 * @author Federico
 */
public class HotSale implements EstrategiaPrecios {

    @Override
    public double calcularPrecio(Producto producto) {
        return producto.getPrecioLista() * 0.75;
    }       
    
}