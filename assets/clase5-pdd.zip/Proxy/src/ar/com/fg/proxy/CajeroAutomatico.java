/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.proxy;

/**
 *
 * @author Federico
 */
class CajeroAutomatico implements AccesoCajero{
    
    public void extraerDinero(double monto) {
        
    }
    
    public void hacerTransferencia(double monto, String cbu) {
        
    }

    @Override
    public void ingresarTarjeta(int pin) {
        System.out.println("Ingresando tarjeta");
    }

    @Override
    public void hacerDeposito(double monto) {
        System.out.println("Haciendo depósito");
    }

    @Override
    public void retirarTarjeta() {
        System.out.println("Retirando tarjeta");
    }
    
}
