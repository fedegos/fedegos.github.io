/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.proxy;

/**
 *
 * @author Federico
 */
public class ProxyCajero implements AccesoCajero {
    
    private CajeroAutomatico cajero;
    
    public ProxyCajero() {
        cajero = new CajeroAutomatico();
    }

    @Override
    public void ingresarTarjeta(int pin) {
        cajero.ingresarTarjeta(pin);
    }

    @Override
    public void hacerDeposito(double monto) {
        cajero.hacerDeposito(monto);
    }

    @Override
    public void retirarTarjeta() {
        cajero.retirarTarjeta();
    }
    
}
