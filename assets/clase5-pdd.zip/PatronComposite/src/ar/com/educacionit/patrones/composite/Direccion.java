package ar.com.educacionit.patrones.composite;

public class Direccion extends Composite {
}
