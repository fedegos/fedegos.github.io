package ar.com.educacionit.patrones.composite.entidades;

public interface IPersonal {
    public void getDatosPersonal();
}
