package ar.com.educacionit.patrones.composite;

public class Escuela extends Composite {
}
