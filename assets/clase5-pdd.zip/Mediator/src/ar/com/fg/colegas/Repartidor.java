/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.colegas;

import ar.com.fg.mediador.Mediador;
import ar.com.fg.pedidos.Pedido;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Federico
 */
public class Repartidor implements Colega {
    
    private Mediador mediador;
    private List<Pedido> pedidosPendientes = new ArrayList<>();
    
    public Repartidor() {}

    @Override
    public void setMediador(Mediador mediador) {
        this.mediador = mediador;
    }

    @Override
    public void nuevoPedido(Pedido pedido) {
        pedidosPendientes.add(pedido);
    }
    
    public void tomarPrimerPedidoPendiente() {
        if (pedidosPendientes.isEmpty()) {
            System.out.println("No hay pedidos pendientes");
            return;
        }
        
        Pedido pedido = pedidosPendientes.get(0);
        System.out.println("Entregando pedido " + pedido.getDescripcion());
        mediador.tomarPedido(pedido);
    }

    @Override
    public void pedidoTomado(Pedido pedido) {       
        pedidosPendientes.remove(pedido);
    }

    @Override
    public void pedidosCancelados(List<Pedido> pedidos) {
        System.out.println("Pedidos antes de cancelacion: " + pedidosPendientes.size());
        for (Pedido pedido: pedidos) {
            pedidosPendientes.remove(pedido);
        }        
        System.out.println("Pedidos después de cancelacion: " + pedidosPendientes.size());
    }
   
    
}
