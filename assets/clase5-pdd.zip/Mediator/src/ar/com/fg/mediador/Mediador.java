package ar.com.fg.mediador;

import ar.com.fg.colegas.Colega;
import ar.com.fg.pedidos.Pedido;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Federico
 */
public interface Mediador {
    
    public void registrarColega(Colega colega);
    
    public void infomarPedidoNuevo(Pedido pedido);
    
    public void tomarPedido(Pedido pedido);
    
    public void cancelarPedidos(List<Pedido> pedidos);
    
    public void desuscribirse(Colega colega);
    
}
