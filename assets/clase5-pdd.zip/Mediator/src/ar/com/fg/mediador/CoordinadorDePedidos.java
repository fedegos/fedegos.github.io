/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.mediador;

import ar.com.fg.colegas.Colega;
import ar.com.fg.pedidos.Pedido;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Federico
 */
public class CoordinadorDePedidos implements Mediador {

    private List<Colega> colegas = new ArrayList<>();
    
    @Override
    public void registrarColega(Colega colega) {
        colega.setMediador(this);
        colegas.add(colega);
    }

    @Override
    public void infomarPedidoNuevo(Pedido pedido) {
        for (Colega colega: colegas) {
            colega.nuevoPedido(pedido);
        }
    }

    @Override
    public void tomarPedido(Pedido pedido) {
        for (Colega colega: colegas) {
            colega.pedidoTomado(pedido);
        }
    }

    @Override
    public void cancelarPedidos(List<Pedido> pedidos) {
        System.out.println("Cancelando " + pedidos.size() + " pedidos." );
        for (Colega colega: colegas) {
            colega.pedidosCancelados(pedidos);
        }
    }

    @Override
    public void desuscribirse(Colega colega) {
        colegas.remove(colega);
        colega.setMediador(null);
    }
    
    
    
}
