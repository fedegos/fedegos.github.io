/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.pedidos;

import ar.com.fg.colegas.Restaurant;

/**
 *
 * @author Federico
 */
public class Pedido {
    
    private Restaurant restaurant;
    private String descripcion;
    
    public Pedido(Restaurant restaurant, String descripcion) {
        this.restaurant = restaurant;
        this.descripcion = descripcion;
    }

    /**
     * @return the restaurant
     */
    public Restaurant getRestaurant() {
        return restaurant;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }
    
    
    
    
}
