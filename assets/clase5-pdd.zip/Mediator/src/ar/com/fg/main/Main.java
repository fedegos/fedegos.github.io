/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.colegas.Repartidor;
import ar.com.fg.colegas.Restaurant;
import ar.com.fg.mediador.CoordinadorDePedidos;
import ar.com.fg.mediador.Mediador;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Informar baja de colega - hay que implementar cancelarPedidos
        
        Mediador mediador = new CoordinadorDePedidos();
        
        Restaurant banchero = new Restaurant("Banchero");
        Restaurant laContinental = new Restaurant("La Continental");
        Restaurant sigaLaVaca = new Restaurant("Siga La Vaca");
        
        Repartidor rep1 = new Repartidor();
        Repartidor rep2 = new Repartidor();
        Repartidor rep3 = new Repartidor();
        Repartidor rep4 = new Repartidor();
        
        mediador.registrarColega(banchero);
        mediador.registrarColega(laContinental);
        mediador.registrarColega(sigaLaVaca);
        
        mediador.registrarColega(rep1);
        mediador.registrarColega(rep2);
        mediador.registrarColega(rep3);
        mediador.registrarColega(rep4);
        
        banchero.crearPedido("Pizza napolitana");
        banchero.crearPedido("Pizza fugazzeta");
        sigaLaVaca.crearPedido("Parrillada");
        laContinental.crearPedido("2 docenas de empanadas");
        sigaLaVaca.crearPedido("Parrillada para 2");
        sigaLaVaca.crearPedido("Parrillada para 3 - comen 4");        
        laContinental.crearPedido("2 docenas de empanadas y un pancito");
        
        rep1.tomarPrimerPedidoPendiente();
        rep2.tomarPrimerPedidoPendiente();
        rep1.tomarPrimerPedidoPendiente();
        rep3.tomarPrimerPedidoPendiente();
        rep4.tomarPrimerPedidoPendiente();
        rep4.tomarPrimerPedidoPendiente();
        rep4.tomarPrimerPedidoPendiente();
        rep4.tomarPrimerPedidoPendiente();
        
        laContinental.crearPedido("2 docenas de empanadas");        
        rep1.tomarPrimerPedidoPendiente();
        rep2.tomarPrimerPedidoPendiente();
        
        sigaLaVaca.crearPedido("Parrillada para 4 - comen 5");        
        sigaLaVaca.crearPedido("Parrillada para 4 - comen 3");        
        sigaLaVaca.crearPedido("Parrillada para 4 - se quedan todos con hambre");        
        
        sigaLaVaca.cerrarRestaurant();
        
        
    }
    
}
