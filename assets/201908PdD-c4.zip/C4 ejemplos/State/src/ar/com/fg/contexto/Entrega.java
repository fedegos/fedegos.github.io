/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.contexto;

import ar.com.fg.estados.EnDeposito;
import ar.com.fg.estados.EnReparto;
import ar.com.fg.estados.Entregada;
import ar.com.fg.estados.Estado;
import ar.com.fg.estados.Iniciada;

/**
 *
 * @author Federico
 */
public class Entrega {
    
    private Estado estado;
    private String id;
    
    public Entrega(String id) {
        this.estado = new Iniciada();
        this.id = id;
    }
    
    public void setEstado(Estado nuevoEstado) {
        this.estado = nuevoEstado;
    }
    
    public void confirmarOperacion() {
        this.estado.confirmar(this);
    }
    
    public void trackear() {
        this.estado.trackear(id);        
    }
    
    /*
    public void enviarADeposito(){
        this.estado = new EnDeposito();
    }
    
    public void pasarAReparto() {
        this.estado = new EnReparto();
    }
    
    public void confirmarEntrega(){
        this.estado = new Entregada();
    }
*/
               
    
}
