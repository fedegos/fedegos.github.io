/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.contexto.Entrega;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Vamos a agregar un método para informar que la entrega 
        // no pudo ser entregada en el reparto
        
        // Agregar información del contexto en el método trackear (id pedido)
        
        // Vamos a crear una máquina de estados, en los que cada cambio de estado
        // es responsabilidad del estado actual.
        
        Entrega entrega = new Entrega("232423423");        
        entrega.trackear();
        
       //  entrega.enviarADeposito();
        entrega.confirmarOperacion();
        entrega.trackear();
        
        // entrega.pasarAReparto();
        entrega.confirmarOperacion();
        entrega.trackear();
        
        // entrega.confirmarEntrega();
        entrega.confirmarOperacion();
        entrega.trackear();
                
        
        entrega.confirmarOperacion();
        entrega.confirmarOperacion();
        entrega.confirmarOperacion();
        entrega.trackear();
        
    }
    
}
