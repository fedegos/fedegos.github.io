/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.estados;

import ar.com.fg.contexto.Entrega;

/**
 *
 * @author Federico
 */
public class Entregada implements Estado{

    @Override
    public void trackear(String id) {
        System.out.println("La entrega " + id + " se terminó");
    }

    @Override
    public void confirmar(Entrega entrega) {       
        // no-op
    }
    
}
