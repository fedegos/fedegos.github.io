package ar.com.educacionit.patrones.iterator;

import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        Division division = new Division("Mi Sucursal");
        division.add("Empleado 1");
        division.add("Empleado 2");

        Iterator<Empleado> iter = division.iterator();
        while (iter.hasNext()) {
            Empleado empleado = (Empleado) iter.next();
            empleado.print();
        }
    }
}
