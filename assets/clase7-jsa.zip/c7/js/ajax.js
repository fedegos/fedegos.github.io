function ajax(url, metodoHttp) {
    metodo = metodoHttp || "GET";
    const xhr = new XMLHttpRequest();
    xhr.open(metodo, url);
    xhr.send();
    return xhr;
 }