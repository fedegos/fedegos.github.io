
// código previo a la condición

if (condicion) {
	// código en caso de que la condición sea verdadera

}

// código posterior a la condición

if (condicion) {
	// ejecuta si condicion es verdadero
} else {
	// ejecuta si condicion es falso
}

if (edad > 20) {
	alert("usted es mayor de 20 años");
} else if (edad > 15) {
	alert("usted tiene 20 años o menos, pero más de 15");
} else {
 	alert("usted tiene 15 años o menos");
}


// switch

switch (variable) { 
	case "A":
		// sentencias caso A
		break;
	case "B":
		// sentencias caso A
		break;
	case "C":
		break;
	default:
		// resto de los casos
		break;
}


var fecha = new Date();
var fecha = new Date(year, month, day);
var fecha = new Date(year, month, day, hour, minutes, seconds);

fecha.getYear(); // año yyyy
fecha.getMonth(); // mes (-1)
fecha.getISOString() // "yyyy-mm-dd TZ HH:MM:SS mmm"
fecha.getDate(); // número de día en el mes 
fecha.getDay(); // número de 0 al 6, en el que el 0 es domingo.

// métodos para acceder a los elementos del DOM de HTML

document.getElementById("id");
document.querySelector("h1"); // elemento .clase #id
document.querySelector("#titulo"); // elemento con id = título
document.querySelector(".precio"); // elemento con clase = precio