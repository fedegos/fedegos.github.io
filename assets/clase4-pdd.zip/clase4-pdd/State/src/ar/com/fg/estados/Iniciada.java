/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.estados;

import ar.com.fg.contexto.Entrega;

/**
 *
 * @author Federico
 */
public class Iniciada implements Estado{
    private Entrega contexto;
    
    public Iniciada(Entrega contexto) {
        this.contexto = contexto;
    }

    @Override
    public void trackear() {
        System.out.println("La entrega está iniciada - " + contexto.getId());
    }

    @Override
    public void completarFase() {
        Estado nuevoEstado = new EnDeposito(contexto);
        contexto.setEstado(nuevoEstado);
    }

    @Override
    public void fallar() {
      
    }
    
    
    
}
