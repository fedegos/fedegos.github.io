/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.estados;

import ar.com.fg.contexto.Entrega;

/**
 *
 * @author Federico
 */
public class EnReparto implements Estado{
    private Entrega contexto;
    
    public EnReparto(Entrega contexto) {
        this.contexto = contexto;
    }
    @Override
    public void trackear() {
        System.out.println("La entrega está en reparto - " + contexto.getId());
    }

    @Override
    public void completarFase() {
        contexto.setEstado(new Entregada(contexto));
    }

    @Override
    public void fallar() {
        contexto.setEstado(new EnDeposito(contexto));
    }
    
}
