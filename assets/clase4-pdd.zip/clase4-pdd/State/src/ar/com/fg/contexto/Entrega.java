/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.contexto;

import ar.com.fg.estados.EnDeposito;
import ar.com.fg.estados.EnReparto;
import ar.com.fg.estados.Entregada;
import ar.com.fg.estados.Estado;
import ar.com.fg.estados.Iniciada;

/**
 *
 * @author Federico
 */
public class Entrega {
    
    private Estado estado;
    private String id;
        
    public Entrega(String id) {
        this.estado = new Iniciada(this);
        this.id = id;
    }
    
    public String getId() {
        return id;
    }
    
    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    public void trackear() {
        this.estado.trackear();
    }
    
    public void completarFase() {
        this.estado.completarFase();
    }
    
    public void fallar() {
        this.estado.fallar();
    }
    
    /*
    public void enviarADeposito(){
        this.estado = new EnDeposito(this);
    }
    
    public void pasarAReparto() {
        this.estado = new EnReparto(this);
    }
    
    public void confirmarEntrega(){
        this.estado = new Entregada(this);
    }
    */         
    
}
