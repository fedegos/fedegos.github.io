package ar.com.educacionit.patrones.visitor;

public interface Visitable {
    public double accept(Visitor visitor);
}
