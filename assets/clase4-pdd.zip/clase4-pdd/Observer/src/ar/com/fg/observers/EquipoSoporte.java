/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.observers;

import ar.com.fg.subject.EstadoServidor;

/**
 *
 * @author Federico
 */
public class EquipoSoporte implements Observador {

    @Override
    public void actualizar(EstadoServidor estado) {
        if (estado.getEstado() == "con fallas") {
            System.out.println("Activando respuesta de soporte nivel 1");
        } else if (estado.getEstado() == "caido") {
            System.out.println("Activando respuesta de soporte nivel 2 - ¡EMERGENCIA! ");
        } else if (estado.getEstado() == "normal") {
            System.out.println("Soporte se va a descanzar.");
        }
        
    }
    
    
}
