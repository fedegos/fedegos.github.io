package ar.com.educacionit.patrones.iterator;

public class Main {

    public static void main(String[] args) {
        Coleccion coleccion = new Coleccion();
        coleccion.inicializar();
        coleccion.setIteradorPropio(false);
        
        System.out.println("Mostrar vector");
        for (String valor : coleccion) {
            System.out.println(valor);
        }
        System.out.println();

        System.out.println("Mostrar vector con iterador propio");
        coleccion.setIteradorPropio(true);
        for (String valor : coleccion) {
            System.out.println(valor);
        }
        System.out.println();

        System.out.println("Mostrar vector con iterador propio");
        coleccion.remove(5);
        for (String valor : coleccion) {
            System.out.println(valor);
        }
        System.out.println();

        System.out.println("Ordenando de menor a mayor");
        coleccion.ordenarMenorAMayor();
        for (String valor : coleccion) {
            System.out.println(valor);
        }
        System.out.println();

        System.out.println("Mostrar vector con iterador propio");
        coleccion.setIteradorPropio(true);
        for (String valor : coleccion) {
            System.out.println(valor);
        }
    }
}
