package ar.com.educacionit.patrones.iterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Coleccion extends ArrayList<String> {

    private boolean estado = true;

    private class IteratorPropio implements Iterator<String> {

        private int cursor = Coleccion.this.size() - 1;
        private List<String> elementosRemovidos;

        @Override
        public boolean hasNext() {
            return !(cursor == -1);
        }

        @Override
        public String next() {
            try {
                String next = Coleccion.this.get(cursor);
                cursor--;
                return next;
            } catch (IndexOutOfBoundsException e) {
                //Devolver el ultimo elemento por default
                return Coleccion.this.get(0);
            }
        }

        @Override
        public void remove() {
            String elementoRemovido = Coleccion.this.get(cursor);
            elementosRemovidos.add(elementoRemovido);
            Coleccion.this.remove(cursor);
            cursor--;
        }
    }

    public void inicializar() {
        String[] nuevo = {"5", "4", "1", "9", "7", "8", "3", "2", "6"};
        this.addAll(Arrays.asList(nuevo));
    }

    @Override
    public Iterator<String> iterator() {
        if (estado) {
            return new IteratorPropio();
        } else {
            return super.iterator();
        }
    }

    public void setIteradorPropio(boolean estado) {
        this.estado = estado;
    }

    public void ordenarMenorAMayor() {
        Collections.sort(this);        
    }
}
