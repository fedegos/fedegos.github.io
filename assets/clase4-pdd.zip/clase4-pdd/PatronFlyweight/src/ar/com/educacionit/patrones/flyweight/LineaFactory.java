package ar.com.educacionit.patrones.flyweight;

import java.util.ArrayList;
import java.util.List;

public class LineaFactory {

    private List<LineaFlyweight> lineas;

    public LineaFactory() {
        this.lineas = new ArrayList<LineaFlyweight>();
    }

    public LineaFlyweight getLine(String color) {
        // Comprobar si hemos creado una línea con el color solicitado, y devolverla en tal caso
        for (LineaFlyweight linea : this.lineas) {
            if (linea.getColor().equals(color)) {
                System.out.println("Línea de color [" + color + "] encontrada, la devolvemos");
                return linea;
            }
        }

        // Si no ha sido creada la creamos ahora, la agregamos a la lista y la devolvemos
        System.out.println("Creando una línea de color [" + color + "]");

        LineaFlyweight linea = new Linea(color);
        this.lineas.add(linea);

        return linea;
    }
}
