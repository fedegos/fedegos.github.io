/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fg.com.main;

import ar.com.fg.cliente.CarritoDeCompras;
import ar.com.fg.visitables.PorMetro;
import ar.com.fg.visitables.PorPeso;
import ar.com.fg.visitables.PorUnidad;
import ar.com.fg.visitables.Servicio;

/**
 *
 * @author EducaciónIT
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CarritoDeCompras carrito = new CarritoDeCompras();
        
        carrito.agregarProducto(new PorUnidad(2,20));
        carrito.agregarProducto(new PorMetro(1,1));
        carrito.agregarProducto(new PorPeso(24,54));
        carrito.agregarProducto(new PorPeso(2,1));
        carrito.agregarProducto(new PorUnidad(3,2));
        carrito.agregarProducto(new Servicio(24000));
        
        System.out.println("Monto de compra: " + carrito.calcularValorTotal());
        System.out.println("Costo de transporte: " + carrito.calcularCostoTransporte());
        
        
    }
    
}
