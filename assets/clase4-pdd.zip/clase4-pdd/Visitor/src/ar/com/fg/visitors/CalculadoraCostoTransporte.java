/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.visitors;

import ar.com.fg.interfaces.Visitor;
import ar.com.fg.visitables.PorMetro;
import ar.com.fg.visitables.PorPeso;
import ar.com.fg.visitables.PorUnidad;
import ar.com.fg.visitables.Servicio;

/**
 *
 * @author EducaciónIT
 */
public class CalculadoraCostoTransporte implements Visitor {

    private int costoTransporte = 0;
    
    public int getCostoTransporte() {
        return costoTransporte;
    }
    
    @Override
    public void visit(PorMetro visitable) {
        costoTransporte = costoTransporte +  visitable.getMetros();
    }

    @Override
    public void visit(PorUnidad visitable) {
        costoTransporte = costoTransporte +  2 * visitable.getUnidades();        
    }

    @Override
    public void visit(PorPeso visitable) {
        costoTransporte = costoTransporte + 5 * visitable.getPrecioPorKilo();
    }

    @Override
    public void visit(Servicio visitable) {        
    }
    
}
