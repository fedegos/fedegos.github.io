/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.visitables;

import ar.com.fg.interfaces.Visitable;
import ar.com.fg.interfaces.Visitor;

/**
 *
 * @author EducaciónIT
 */
public class PorUnidad implements Visitable {
    
    private int precioUnitario;
    private int unidades;
    
    public PorUnidad(int precio, int cantidad) {
        this.precioUnitario = precio;
        this.unidades = cantidad;
    }

    /**
     * @return the precioUnitario
     */
    public int getPrecioUnitario() {
        return precioUnitario;
    }

    /**
     * @return the unidades
     */
    public int getUnidades() {
        return unidades;
    }    
    

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
}
