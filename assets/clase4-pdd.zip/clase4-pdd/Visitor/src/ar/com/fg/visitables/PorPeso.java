/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.visitables;

import ar.com.fg.interfaces.Visitable;
import ar.com.fg.interfaces.Visitor;

/**
 *
 * @author EducaciónIT
 */
public class PorPeso implements Visitable {

    private int peso;
    private int precioPorKilo;
    
    public PorPeso(int peso, int precio) {
        this.peso = peso;
        this.precioPorKilo = precio;
    }
    
    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @return the precioPorKilo
     */
    public int getPrecioPorKilo() {
        return precioPorKilo;
    }
       
    

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
}
