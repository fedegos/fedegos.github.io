/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.cliente;

import ar.com.fg.interfaces.Visitable;
import ar.com.fg.visitors.CalculadoraCostoTransporte;
import ar.com.fg.visitors.CalculadoraMonto;
import java.util.ArrayList;

/**
 *
 * @author EducaciónIT
 */
public class CarritoDeCompras {       
    
    private ArrayList<Visitable> productos;
    
    public CarritoDeCompras() {
        productos = new ArrayList<>();       
    }
    
    public void agregarProducto(Visitable producto) {
        productos.add(producto);
    }
    
    public int calcularValorTotal() {
        CalculadoraMonto calculadora = new CalculadoraMonto();
        
        for(Visitable producto : productos) {
            producto.accept(calculadora);
        }
        return calculadora.getMontoTotal();
    }
    
    public int calcularCostoTransporte() { 
        CalculadoraCostoTransporte calculadora = new CalculadoraCostoTransporte();
        
        for(Visitable producto : productos) {
            producto.accept(calculadora);
        }
        return calculadora.getCostoTransporte();
        
    }
    
}
