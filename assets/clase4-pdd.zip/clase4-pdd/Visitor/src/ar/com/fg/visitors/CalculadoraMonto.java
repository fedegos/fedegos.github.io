/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.visitors;

import ar.com.fg.interfaces.Visitor;
import ar.com.fg.visitables.PorMetro;
import ar.com.fg.visitables.PorPeso;
import ar.com.fg.visitables.PorUnidad;
import ar.com.fg.visitables.Servicio;

/**
 *
 * @author EducaciónIT
 */
public class CalculadoraMonto implements Visitor {
    
    private int montoTotal;
    
    public CalculadoraMonto() {
        montoTotal = 0;
    }   
    
    @Override
    public void visit(PorMetro visitable) {
        montoTotal = montoTotal + visitable.getMetros() * visitable.getPrecio();
    }

    @Override
    public void visit(PorUnidad visitable) {        
        montoTotal = montoTotal + visitable.getPrecioUnitario() * visitable.getUnidades();
    }

    @Override
    public void visit(PorPeso visitable) {
        montoTotal = montoTotal + visitable.getPeso() * visitable.getPrecioPorKilo();
    }

    /**
     * @return the montoTotal
     */
    public int getMontoTotal() {
        return montoTotal;
    }

    @Override
    public void visit(Servicio visitable) {
        montoTotal = montoTotal + visitable.getPrecio();
    }
    
    
    
}
