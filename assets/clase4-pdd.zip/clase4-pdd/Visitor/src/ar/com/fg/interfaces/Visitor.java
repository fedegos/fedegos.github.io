/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.interfaces;

import ar.com.fg.visitables.PorMetro;
import ar.com.fg.visitables.PorPeso;
import ar.com.fg.visitables.PorUnidad;
import ar.com.fg.visitables.Servicio;

/**
 *
 * @author EducaciónIT
 */
public interface Visitor {
    public void visit(PorMetro visitable);
    public void visit(PorUnidad visitable);
    public void visit(PorPeso visitable);
    public void visit(Servicio visitable);
}
