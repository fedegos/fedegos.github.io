/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.visitables;

import ar.com.fg.interfaces.Visitable;
import ar.com.fg.interfaces.Visitor;

/**
 *
 * @author EducaciónIT
 */
public class Servicio implements Visitable {
    
    private int precio;
    
    public Servicio(int precio) {
        this.precio = precio;
    }
    
    public int getPrecio() {
        return precio;
    }
    
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
}
