/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.visitables;

import ar.com.fg.interfaces.Visitable;
import ar.com.fg.interfaces.Visitor;

/**
 *
 * @author EducaciónIT
 */
public class PorMetro implements Visitable {
    
    private int metros;
    private int precio;
    
    public PorMetro(int metros, int precio) {
        this.metros = metros;
        this.precio = precio;
    }
    
    
    @Override
    public void accept(Visitor calculadora) {
        calculadora.visit(this);
    }

    /**
     * @return the metros
     */
    public int getMetros() {
        return metros;
    }

    /**
     * @return the precio
     */
    public int getPrecio() {
        return precio;
    }
    
}
