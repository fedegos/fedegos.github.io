/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.abstracciones.Auto;
import ar.com.fg.abstracciones.FabricaAutos;
import ar.com.fg.implementaciones.FabricaAutosConcreta;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
            Agregar nuevo auto: Volkswagen Up. ¿Alcanza con crear las clases 
            de implementación para poder usar el nuevo auto?
        
            Agregar método de apagar() a Auto. Adaptar las implementaciones.        
        */        
                
        FabricaAutos fabrica = obtenerFabrica();
        Auto auto = fabrica.fabricarAuto("Chevrolet", "grande");
        auto.prender();
        
        Auto auto2 = fabrica.fabricarAuto("Ford", "chico");
        auto2.prender();
        
        Auto auto3 = fabrica.fabricarAuto("Volkswagen", "mediano");
        auto3.prender();
        
        
    }
    
    public static FabricaAutos obtenerFabrica() {
       return new FabricaAutosConcreta();
    }
    
}
