/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.implementaciones;

import ar.com.fg.abstracciones.Auto;
import ar.com.fg.abstracciones.FabricaAutos;

/**
 *
 * @author EducaciónIT
 */
public class FabricaAutosConcreta implements FabricaAutos {

    @Override
    public Auto fabricarAuto(String marca, String tamano) {
        switch (marca) {
            case ("Ford"): {
                switch(tamano) {
                    case("chico"): {
                        return new FordFiesta();
                    }
                    
                    case("mediano"): {
                        return new FordFocus();
                    }
                    
                    case("grande"): {
                        return new FordMondeo();
                    }
                }
            }
            
            case("Chevrolet"): {
                switch(tamano) {
                    case("chico"): {
                        return new ChevroletAgile();
                    }
                    
                    case("mediano"): {
                        return new ChevroletOnix();
                    }
                    
                    case("grande"): {
                        return new ChevroletCruze();
                    }
                }                
            }
            
            case("Volkswagen"): {
                switch(tamano) {
                    case("chico"): {
                        return new VolkswagenUp();
                    }
                    
                    case("mediano"): {
                        return new VolkswagenGolf();
                    }
                    
                    case("grande"): {
                        return new VolkswagenVento();
                    }
                }                
            }
            
        }
        
        return null;        
    }
    
}
