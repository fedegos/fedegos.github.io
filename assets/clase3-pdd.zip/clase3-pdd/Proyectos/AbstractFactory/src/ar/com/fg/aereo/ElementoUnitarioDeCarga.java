/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.aereo;

import ar.com.fg.abstracciones.Almacenamiento;

/**
 *
 * @author Federico
 */
public class ElementoUnitarioDeCarga implements Almacenamiento{
    
    private String manifiesto;
    
    @Override
    public void agregarCarga(String manifiestoDeCarga) {
        manifiesto = manifiestoDeCarga;        
    }

    @Override
    public String obtenerManifiesto() {
        return this.manifiesto + " en un ULD."; 
    }
    
}
