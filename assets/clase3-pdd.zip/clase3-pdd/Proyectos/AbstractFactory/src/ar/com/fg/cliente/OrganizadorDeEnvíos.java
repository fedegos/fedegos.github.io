/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.cliente;

import ar.com.fg.abstracciones.Almacenamiento;
import ar.com.fg.abstracciones.FabricaEnvios;
import ar.com.fg.abstracciones.Transporte;

/**
 *
 * @author Federico
 */
public class OrganizadorDeEnvíos {

    private FabricaEnvios fabrica;

    public OrganizadorDeEnvíos(FabricaEnvios fabrica) {
        this.fabrica = fabrica;
    }
    
    public void enviarCarga(String carga) {
        Transporte transporte = fabrica.crearTransporte();
        Almacenamiento almacenamiento = fabrica.crearAlmacenamiento();
        almacenamiento.agregarCarga(carga);
        
        transporte.transportar(almacenamiento);        
    }

}
