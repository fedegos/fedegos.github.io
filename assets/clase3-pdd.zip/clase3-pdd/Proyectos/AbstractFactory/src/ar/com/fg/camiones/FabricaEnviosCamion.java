/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.camiones;

import ar.com.fg.abstracciones.Almacenamiento;
import ar.com.fg.abstracciones.FabricaEnvios;
import ar.com.fg.abstracciones.Transporte;

/**
 *
 * @author Federico
 */
public class FabricaEnviosCamion implements FabricaEnvios {

    @Override
    public Transporte crearTransporte() {
        return new Camion();        
    }

    @Override
    public Almacenamiento crearAlmacenamiento() {
        return new Pallet();
    }
    
}
