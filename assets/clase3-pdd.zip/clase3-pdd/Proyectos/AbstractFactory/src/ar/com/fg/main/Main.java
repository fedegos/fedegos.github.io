/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.abstracciones.FabricaEnvios;
import ar.com.fg.aereo.FabricaEnviosAereos;
import ar.com.fg.camiones.FabricaEnviosCamion;
import ar.com.fg.cliente.OrganizadorDeEnvíos;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Ejercicios:
        
        Ralizar un envío de notebooks por avión.
        
        Implementar envíos por barco (el almacenamiento es un Contaier)
        
        BONUS: 
        Modificar el código de Almacenamiento.agregarCarga() para que también 
        reciba como parámetro la cantidad. Adecuar las implementaciones 
        concretas. Mostrar la cantidad al obtenerManifiesto() en cada caso.
                        
        */
        
        FabricaEnvios enviosPorCamion = new FabricaEnviosCamion();
        OrganizadorDeEnvíos organizador = new OrganizadorDeEnvíos(enviosPorCamion);       
        organizador.enviarCarga("Limones");        
        
        FabricaEnvios enviosAereos = new FabricaEnviosAereos();
        OrganizadorDeEnvíos org2 = new OrganizadorDeEnvíos(enviosAereos);
        org2.enviarCarga("Notebooks");
        
        
    }
    
}
