/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.abstraccionesrefinadas;

import ar.com.fg.abstraccion.AplicacionWeb;
import ar.com.fg.implementador.Tema;

/**
 *
 * @author Federico
 */
public class Blog extends AplicacionWeb {
    
    public Blog(Tema tema) {
        super(tema);
    }
    
    public void mostrarPost() {         
        System.out.println("*** Dibujando post ***");
        
        this.tema.dibujarTitulo();
        this.tema.insertarImagen();
        this.tema.dibujarParrafo();
        this.tema.dibujarParrafo();
        this.tema.dibujarParrafo();
    }
}

