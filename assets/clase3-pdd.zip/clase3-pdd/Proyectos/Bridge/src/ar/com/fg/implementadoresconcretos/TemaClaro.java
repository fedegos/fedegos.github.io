/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.implementadoresconcretos;

import ar.com.fg.implementador.Tema;

/**
 *
 * @author Federico
 */
public class TemaClaro implements Tema {
    
    @Override
    public void dibujarTitulo() {
        System.out.println("Dibujando título claro");
    }

    @Override
    public void dibujarBoton() {
        System.out.println("Dibujando botón claro");
    }

    @Override
    public void dibujarTabla() {
        System.out.println("Dibujando tabla clara");
    }

    @Override
    public void dibujarParrafo() {
        System.out.println("Dibujando párrafo claro");
    }

    @Override
    public void dibujarGaleria() {
        System.out.println("Dibujando galería clara");
    }

    @Override
    public void insertarImagen() {
        System.out.println("Insertando imagen con marco claro");
    }
    
}
