/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.abstraccion;

import ar.com.fg.implementador.Tema;

/**
 *
 * @author Federico
 */
public class AplicacionWeb {
    
    protected Tema tema;
    
    public AplicacionWeb(Tema tema) {
        this.tema = tema;
    }
    
    public void mostrarPaginaInicio() {
        
        System.out.println("*** Dibujando inicio ***");
        
        tema.dibujarTitulo();
        tema.dibujarParrafo();
        tema.dibujarBoton();
        tema.dibujarBoton();
        tema.dibujarGaleria();
        tema.insertarImagen();
        tema.insertarImagen();
        tema.insertarImagen();
    }
}
