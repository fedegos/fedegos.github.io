/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.abstraccionesrefinadas.Blog;
import ar.com.fg.implementador.Tema;
import ar.com.fg.implementadoresconcretos.TemaOscuro;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {       
        /* 
        Ejercicios:
        
        Crear un ecommerce, mostrar la pagina de inicio y un producto con tema 
        claro.
        
        Crear un portal de noticias, mostrar la pagina de inicio y una noticia 
        con tema oscuro.
        
        Agregar un método en Ecommerce que muestre una categoría, con un título, 
        una galería y 3 imágenes.
        
        Agregar un método en Tema que permite dibujar una lista. Adecuar los 
        implementadores.
        
        Agregar un implementador concreto de Tema "Minimalista".                
        
        */
        
        Tema temaOscuro = new TemaOscuro();
        Blog blog = new Blog(temaOscuro);
                
        blog.mostrarPaginaInicio();        
        blog.mostrarPost();
        
        
        
        
    }
    
}
