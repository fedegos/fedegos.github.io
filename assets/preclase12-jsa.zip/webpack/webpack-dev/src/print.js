export default function printMe() {
    cosnole.log('I get called from print.js!'); // Acá está el error
}