package ar.com.educacionit.patrones.abstractfactory.elements;

public abstract class Color {
    public abstract void colorea(TV tv);
}
