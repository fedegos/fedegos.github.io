package ar.com.educacionit.patrones.abstractfactory.impl;

import ar.com.educacionit.patrones.abstractfactory.AbstractFactory;
import ar.com.educacionit.patrones.abstractfactory.elements.Color;
import ar.com.educacionit.patrones.abstractfactory.elements.TV;
import ar.com.educacionit.patrones.abstractfactory.elements.concrete.Azul;
import ar.com.educacionit.patrones.abstractfactory.elements.concrete.LCD;

public class FactoryLcdAzul extends AbstractFactory {
    @Override
    public Color createColor() {
        return new Azul();
    }

    @Override
    public TV createTV() {
        return new LCD();
    }
}
