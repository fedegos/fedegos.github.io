package ar.com.educacionit.patrones.abstractfactory;

import ar.com.educacionit.patrones.abstractfactory.elements.Color;
import ar.com.educacionit.patrones.abstractfactory.elements.TV;

public abstract class AbstractFactory {
    public abstract TV createTV();

    public abstract Color createColor();
}
