package ar.com.educacionit.patrones.abstractfactory.elements.concrete;

import ar.com.educacionit.patrones.abstractfactory.elements.TV;

public class LCD extends TV {
    @Override
    public String getDescripcion() {
        return "LCD";
    }
}
