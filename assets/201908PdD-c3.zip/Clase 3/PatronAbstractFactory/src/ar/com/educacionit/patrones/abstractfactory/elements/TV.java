package ar.com.educacionit.patrones.abstractfactory.elements;

public abstract class TV {
    public abstract String getDescripcion();
}
