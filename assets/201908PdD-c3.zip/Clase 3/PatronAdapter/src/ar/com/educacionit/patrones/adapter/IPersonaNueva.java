package ar.com.educacionit.patrones.adapter;

public interface IPersonaNueva {
    public String getNombre();

    public void setNombre(String nombre);

    public int getEdad();

    public void setEdad(int edad);
}
