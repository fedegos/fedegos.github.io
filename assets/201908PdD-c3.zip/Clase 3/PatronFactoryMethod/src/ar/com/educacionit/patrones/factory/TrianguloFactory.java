package ar.com.educacionit.patrones.factory;

import ar.com.educacionit.patrones.factory.model.Equilatero;
import ar.com.educacionit.patrones.factory.model.Escaleno;
import ar.com.educacionit.patrones.factory.model.Isosceles;
import ar.com.educacionit.patrones.factory.model.Triangulo;

public class TrianguloFactory {
    public Triangulo createTriangulo(int ladoA, int ladoB, int ladoC) {
        if ((ladoA == ladoB) && (ladoA == ladoC)) {
            return new Equilatero(ladoA, ladoB, ladoC);
        } else if ((ladoA != ladoB) && (ladoA != ladoC) && (ladoB != ladoC)) {
            return new Escaleno(ladoA, ladoB, ladoC);
        } else {
            return new Isosceles(ladoA, ladoB, ladoC);
        }
    }
}
