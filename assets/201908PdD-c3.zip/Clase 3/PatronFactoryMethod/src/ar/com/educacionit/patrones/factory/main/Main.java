package ar.com.educacionit.patrones.factory.main;

import ar.com.educacionit.patrones.factory.TrianguloFactory;
import ar.com.educacionit.patrones.factory.model.Triangulo;

public class Main {
    public static void main(String[] args) {
        TrianguloFactory factory = new TrianguloFactory();

        Triangulo triangulo = factory.createTriangulo(10, 10, 10);
        System.out.println(triangulo.getDescripcion());
    }
}
