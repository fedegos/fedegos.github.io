/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.builder.main;

import ar.com.fg.builder.actores.Sandwich;
import ar.com.fg.builder.actores.SandwichMaker;
import ar.com.fg.builder.actores.TipoDeCarne;
import ar.com.fg.builder.actores.TipoDePan;
import ar.com.fg.builder.actores.TipoDeQueso;
import ar.com.fg.builder.builders.BondiolaYFiladelfiaBuilder;
import ar.com.fg.builder.builders.LomoBuilder;
import java.util.Arrays;

/*
import ar.com.fg.builder.actores.Sandwich;
import ar.com.fg.builder.actores.TipoDeCarne;
import ar.com.fg.builder.actores.TipoDePan;
import ar.com.fg.builder.actores.TipoDeQueso;
import java.util.ArrayList;
import java.util.Arrays;
*/

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Ejemplo creación sin Builder        

        Sandwich sandwich = new Sandwich();
        
        sandwich.setTipoDePan(TipoDePan.MIGA);
        sandwich.setEsTostado(true);
        
        sandwich.setTipoDeCarne(TipoDeCarne.POLLO);
        sandwich.setTipoDeQueso(TipoDeQueso.MUZZARELLA);
        
        sandwich.setTieneMayonesa(true);
        sandwich.setTieneMostaza(false);
        sandwich.setVegetales(Arrays.asList("Albahaca", "Tomates secos"));
        
        sandwich.Mostrar();         
        
        System.out.println("");
        System.out.println("***");
        System.out.println("");
        
        // Ejemplos con Builder
        SandwichMaker lomoMaker = new SandwichMaker(new LomoBuilder());
        lomoMaker.BuildSanwdich();
        Sandwich sandwichDeLomo = lomoMaker.GetSandwich();
        
        sandwichDeLomo.Mostrar();
        
        System.out.println("");
        System.out.println("***");
        System.out.println("");

        SandwichMaker bondiolaMaker = new SandwichMaker(new BondiolaYFiladelfiaBuilder());
        bondiolaMaker.BuildSanwdich();
        Sandwich sandwichDeBondiola = bondiolaMaker.GetSandwich();
        
        sandwichDeBondiola.Mostrar();
        
    }
    
}
