/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author Federico
 */
public abstract class RedSocial {
    
    public boolean postear(String mensaje) {
        if (login()) {            
            logout();
            enviarDatos(mensaje);
            return true;
        }
        return false;
    }
    
    //abstract void promocionarPublicacion();
    abstract boolean login();
    abstract void enviarDatos(String mensaje);
    abstract void logout();
    
}
