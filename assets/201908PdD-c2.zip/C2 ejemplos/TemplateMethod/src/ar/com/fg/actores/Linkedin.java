/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author EducaciónIT
 */
public class Linkedin extends RedSocial {
    private String token; 
    
    public Linkedin(String token) {
        this.token = token;
    }
            
    @Override
    boolean login() {
        System.out.println("Logueandose a Linkedin");
        return true;
    }

    @Override
    void enviarDatos(String mensaje) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void logout() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
