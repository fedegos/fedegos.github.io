/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author Federico
 */
public abstract class PlantillaPedido {
    
    protected boolean esRegalo; 
    
    public abstract void checkout();
    public abstract void cobrar();
    public abstract void emitirFactura();
    public abstract void entregar();
    
    public void envolverRegalo() {
        System.out.println("Envolviendo regalo");
    }   
    
    public void avisoPostEnvio() {
    }
    
    public final void procesarPedido() {
        checkout();
        cobrar();
     
        if(esRegalo) {
            envolverRegalo();
        } 
        emitirFactura();
        entregar();
        avisoPostEnvio();
       
    }
    
    
}
