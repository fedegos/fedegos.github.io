/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author Federico
 */
public class PedidoOnline extends PlantillaPedido {

    public PedidoOnline(boolean esRegalo) {
        this.esRegalo = esRegalo;
    }
    
    @Override
    public void checkout() {
        System.out.println("Ingresando dirección de entrega");
        System.out.println("Ingresando datos personales");
        System.out.println("Ingresando datos de tarjeta");
        System.out.println("Calculando valor de pedido");
        
    }

    @Override
    public void cobrar() {
        System.out.println("Cobrando con tarjeta");
    }

    @Override
    public void emitirFactura() {
        System.out.println("Enviando factura por email");
    }

    @Override
    public void entregar() {
        System.out.println("Enviando pedido a dirección de entrega");
    }
    
    
}


