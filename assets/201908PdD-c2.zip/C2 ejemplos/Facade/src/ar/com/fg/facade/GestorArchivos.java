/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.facade;

import ar.com.fg.legacy.Archivo;
import ar.com.fg.legacy.Conexion;

/**
 *
 * @author Federico
 */
public class GestorArchivos {
    private Conexion conexion;
   
    public GestorArchivos(String usuario) {
        conexion = new Conexion();
        conexion.conectar(usuario);
    }
    
    public Archivo obtenerArchivo(String unidad, String directorio, String archivo) {
        return conexion.obtenerUnidad(unidad)
                .obtenerDirectorio(directorio)
                .obtenerArchivo(archivo);
    }
    
}
