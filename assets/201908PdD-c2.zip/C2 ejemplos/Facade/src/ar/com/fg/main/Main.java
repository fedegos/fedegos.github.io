/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.facade.GestorArchivos;
import ar.com.fg.legacy.Archivo;
import ar.com.fg.legacy.Conexion;
import ar.com.fg.legacy.Directorio;
import ar.com.fg.legacy.Unidad;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // sin Facade
        Conexion conexion = new Conexion();
        conexion.conectar("federico");
        
        Unidad unidad = conexion.obtenerUnidad("miunidad");
        Directorio directorio = unidad.obtenerDirectorio("Mis Documentos");
        Archivo archivo = directorio.obtenerArchivo("Patrones de diseño.pdf");        
        
        // con Facade
        GestorArchivos gestor = new GestorArchivos("federico");        
        Archivo archivo2 = gestor.obtenerArchivo("miunidad", "Mis Documentos", "Patrones de diseño - segunda edición.pdf");        
        
    }
    
}

