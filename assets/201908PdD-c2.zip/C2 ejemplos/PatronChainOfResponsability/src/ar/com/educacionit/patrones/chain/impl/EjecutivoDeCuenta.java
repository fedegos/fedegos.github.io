package ar.com.educacionit.patrones.chain.impl;

import ar.com.educacionit.patrones.chain.IAprobador;

public class EjecutivoDeCuenta extends Aprobador {

    @Override
    public void solicitudPrestamo(int monto) {
        if (monto <= 10000) {
            System.out.println("Lo manejo yo, el ejecutivo de cuentas");
        } else {
            next.solicitudPrestamo(monto);
        }
    }

 
}
