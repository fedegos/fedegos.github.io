package ar.com.educacionit.patrones.chain.impl;

import ar.com.educacionit.patrones.chain.IAprobador;

public class LiderTeamEjecutivo extends Aprobador {


    @Override
    public void solicitudPrestamo(int monto) {
        if (monto <= 50000) {
            System.out.println("Lo manejo yo, el lider");
        } else {
            next.solicitudPrestamo(monto);
        }
    }

}
