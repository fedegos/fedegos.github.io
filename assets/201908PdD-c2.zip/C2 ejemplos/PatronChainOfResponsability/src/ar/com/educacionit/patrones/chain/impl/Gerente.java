package ar.com.educacionit.patrones.chain.impl;

import ar.com.educacionit.patrones.chain.IAprobador;

public class Gerente extends Aprobador {

    @Override
    public void solicitudPrestamo(int monto) {
        if (monto > 50000 && monto <= 100000) {
            System.out.println("Lo manejo yo, el gerente");
        } else {
            next.solicitudPrestamo(monto);
        }
    }

}
