package ar.com.educacionit.patrones.chain.main;

import ar.com.educacionit.patrones.chain.impl.Banco;

public class Main {
    public static void main(String[] args) {
        Banco banco = new Banco();
        banco.solicitudPrestamo(10000);
    }
}
