package ar.com.educacionit.patrones.chain.impl;

import ar.com.educacionit.patrones.chain.IAprobador;

public class Director extends Aprobador {


    @Override
    public void solicitudPrestamo(int monto) {        
        System.out.println("Lo manejo yo, el director");                
    }
    
    
}
