/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.receivers;

/**
 *
 * @author Federico
 */
public class Luz {
    
    private boolean estaPrendida;
    
    public Luz() {
        estaPrendida = false;
    }
    
    public void prender() {
        System.out.println("Luz prendida");
        estaPrendida = true;
    }
    
    public void apagar() {
        System.out.println("Luz apagada");
        estaPrendida = false;        
    }
    
    public void alternar() {
        estaPrendida = !estaPrendida;
        if (estaPrendida) {
            System.out.println("La luz está prendida");
        } else {
            System.out.println("La luz está apagada");
        }
    }
    
    
}
