/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.comandos;

import ar.com.fg.actores.Command;
import ar.com.fg.receivers.Luz;

/**
 *
 * @author EducaciónIT
 */
public class AlternarLuz implements Command {

    private Luz luz;
    
    public AlternarLuz(Luz luz) {
        this.luz = luz;    
    }
    
    @Override
    public void ejecutar() {
        luz.alternar();
    }
    
    
    
    
}
