
// La siguiente sentencia muestra el mensaje de bienvenida
// alert('bienvenidos desde codigo.js');

/*
	Reglas para definir nombres de variables:

	- Se pueden usar letras, números y los signos "$" y "_"
	- No se pueden usar otros símbolos, como "-" y "."
	- El nombre de la variable no puede empezar con un número.
	- Las variables son case-sensitive (sensibles a las mayúsculas)

*/

// ejemplos de definición de variables
var nombre;
var $precio;
var _edad;
var cantidad1;
var $_$cantidad2;

// no es lo mismo var nombre que var Nombre 

// nombres de variables inválidos
// var 1nombre;
// var persona.edad;

// inicializar
nombre = "Federico";
alert(nombre);
nombre = 5;
alert(nombre);
var nombreYApellido = "Federico Gosman";

// cadena
var cadena1 = "Hola";
var cadena2 = 'Mundo';
var cadena3 = "'Hola' mundo";
var cadena4 = 'Hola "mundo"';

alert(cadena3);


números
var numero1 = 23; // Integer
var numero2 = 23.5; // Float 
var noEsNumero = "24"; // ¡NO ES NÚMERO! Es un String (cadena de texto, o simplemente cadena) 

alert(numero1 + noEsNumero);
alert(numero1 + parseInt(noEsNumero));

// booleanos
var esVerdad = true;
var esFalso = false;

// operadores 

// operadores de asignación
var pi = 3.14;

// operadores matemáticos
var x = 10;
var y = 20;


// suma
console.log(x + y);
// multiplicación
console.log(x * y);
// división
console.log(x / y);
// resta
console.log(x - y);
// módulo
console.log(x % y);
// exponencial
console.log(x ** 2);

// operadores combinados matemáticos y de asignación
x += 2; // x = x + 2;
x -= 2;
x *= 2;
x /= 2;
x %= 2;

console.log(x);

// operadores de incremento y decremento

// // incrementar
x++; // Es lo mismo que: x = x + 1 -- O -- x += 1
console.log(x);

// decrementar
x--; // Es lo mismo que: x = x - 1 -- O -- x -= 1
console.log(x);

z = y + 1;
console.log(z);
console.log(y); // el valor de y no cambia


// operadores relacionales

var x = 10;
var y = 20;
var resultado1 = x < y;
var resultado2 = x <= y;
var resultado3 = x >= y;
var resultado4 = x > y;
var resultado5 = x == y - 10; // 20 - 10 = 10
var resultado6 = x != y;

// document.write: output al documento HTML

document.write(resultado1 + "<br>");
document.write(resultado2 + "<br>");
document.write(resultado3 + "<br>");
document.write(resultado4 + "<br>");
document.write(resultado5 + "<br>");
document.write(resultado6 + "<br>");


// prompt: ventana de entrada para capturar información del usuario
var edad = prompt('ingrese su edad:');

alert("su edad es: " + edad);

// confirm: ventana de confirmación del usuario

var confirmado = confirm('¿Está seguro?');
alert(confirmado);

