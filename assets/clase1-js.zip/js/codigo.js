
// // La siguiente sentencia muestra el mensaje de bienvenida
// // alert('bienvenidos desde codigo.js');

// // ejemplos de definición de variables
// var nombre;
// var $precio;
// var _edad;
// var cantidad1;
// var $_$cantidad2;

// // no es lo mismo var nombre que var Nombre 

// // nombres de variables inválidos
// // var 1nombre;
// // var persona.edad;

// // inicializar
// nombre = "Federico";
// alert(nombre);
// nombre = 5;
// alert(nombre);
// var nombreYApellido = "Federico Gosman";

// // cadena
// var cadena1 = "Hola";
// var cadena2 = 'Mundo';
// var cadena3 = "'Hola' mundo";
// var cadena4 = 'Hola "mundo"';

// alert(cadena3);


// números
// var numero1 = 23; // Integer
// var numero2 = 23.5; // Float 
// var noEsNumero = "24"; // NO ES NÚMERO! Es String (cadena) 

// alert(numero1 + noEsNumero);
// alert(numero1 + parseInt(noEsNumero));

// // booleanos
// var esVerdad = true;
// var esFalso = false;

// // operadores
// // asignación
// var pi = 3.14;

// matemáticos
// var x = 10;
// var y = 20;

// // suma
// console.log(x + y);
// // multiplicación
// console.log(x * y);
// // división
// console.log(x / y);
// // resta
// console.log(x - y);
// // módulo
// console.log(x % y);
// // exponencial
// console.log(x ** 2);

// // asignación de suma
// x += 2; // x = x + 2;
// x -= 2;
// x *= 2;
// x /= 2;
// x %= 2;
// console.log(x);

// // incrementar
// x++; // x = x + 1 -- O -- x += 1
// console.log(x);
// // decrementar
// x--;
// console.log(x);

// z = y + 1;
// console.log(z);

// console.log(y);>

// operadores lógicos

var x = 10;
var y = 20;
var resultado1 = x < y;
var resultado2 = x <= y;
var resultado3 = x >= y;
var resultado4 = x > y;
var resultado5 = x == y - 10; // 20 - 10 = 10
var resultado6 = x != y;

document.write(resultado1 + "<br>");
document.write(resultado2 + "<br>");
document.write(resultado3 + "<br>");
document.write(resultado4 + "<br>");
document.write(resultado5 + "<br>");
document.write(resultado6 + "<br>");

var edad = prompt('ingrese su edad:');

alert("su edad es: " + edad);

var confirmado = confirm('¿Está seguro?');
alert(confirmado);

