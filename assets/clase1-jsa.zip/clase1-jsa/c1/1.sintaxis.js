// Tipos de datos

// bool

var booleanoVerdadero = true;
var booleanoFalso = false;

// null

var nada = null;

// undefined

var sinValorAun;

sinValorAun == undefined; // Devuelve true

// Number

var entero = 94;
var puntoFlotante = 3.14;

// String
var hola = "Mundo!";
var cadena = 'Otra forma de definir un string';
var otraCadena = `Esta forma nos permite interpolar variables como ${cadena}`;


var montoDeVenta = 432;

var mensaje = `El monto de la venta es de $ ${montoDeVenta}.`;

alert(mensaje);


var simbolo = Symbol("foo"); // Nuevo en ECMAScript6. Es inmutable
Symbol("foo") == Symbol("foo"); // Esto devuelve false.

/*
    Symbol("cadena") no convierte la cadena en un Symbol, sino que crea
    un símbolo nuevo con esa descripción
*/


// Object

var objeto = { nombre: "Federico", apellido: "Gosman" }

// Array

var arreglo = ["Hola", "mundo", 3.14, objeto, [1,2,3] ];

// Function

var miFuncion = function() { console.log("hola mundo!") }

function miFuncion() { console.log("hola mundo!") }

/*
    miFuncion es un objeto de primera clase. Lo puedo usar como
    cualquier variable, por ejemplo pasándolo como parámetro a
    otras funciones.
*/


// Bloques

// Un bloque es un fragmento de código autocontenido entre llaves.

if (true) {
    // esto es un bloque
}

function MiFuncion() {
    // esto también es un bloque
}
