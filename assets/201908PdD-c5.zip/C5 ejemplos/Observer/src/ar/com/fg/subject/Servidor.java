/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.subject;

import ar.com.fg.observers.Observador;
import java.util.ArrayList;

/**
 *
 * @author Federico
 */
public class Servidor {
    private ArrayList<Observador> lista;
    protected EstadoServidor estado;
    
    public Servidor() {
        this.lista = new ArrayList<Observador>();
    }
            
    public void agregarObservador(Observador observador) {
        lista.add(observador);
    }
    public void quitarObservador(Observador observador) {
        lista.remove(observador);
    }
    
    public void notificar() {
        for (Observador observador: lista) {
            observador.actualizar(estado);
        }
    }
    
}
