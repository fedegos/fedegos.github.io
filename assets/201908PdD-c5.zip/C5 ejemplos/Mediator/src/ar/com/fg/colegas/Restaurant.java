/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.colegas;

import ar.com.fg.mediador.Mediador;
import ar.com.fg.pedidos.Pedido;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Federico
 */
public class Restaurant implements Colega {
    
    private Mediador mediador;
    private List<Pedido> pedidos = new ArrayList<>();
    private String nombre;
    
    public Restaurant(String nombre) {
        this.nombre = nombre;        
    }
    
    public void crearPedido(String descripcion) {
        Pedido pedido = new Pedido(this, descripcion);
        this.pedidos.add(pedido);
        this.mediador.infomarPedidoNuevo(pedido);
    }

    @Override
    public void nuevoPedido(Pedido pedido) {
        // Al restaurant no le importan los pedidos de otros restaurantes.
    }

    @Override
    public void pedidoTomado(Pedido pedido) {
        if (pedido.getRestaurant() == this) {
            this.pedidos.remove(pedido);
            System.out.println("Pedidos pendientes en " 
                    + this.nombre 
                    + ": " + pedidos.size() );
        }
    }

    @Override
    public void setMediador(Mediador mediador) {
        this.mediador = mediador;
    }

    @Override
    public List<Pedido> getPedidosPendientes() {
        return pedidos;
    }
    
}
