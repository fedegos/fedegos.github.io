package ar.com.fg.mediador;

import ar.com.fg.colegas.Colega;
import ar.com.fg.pedidos.Pedido;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Federico
 */
public interface Mediador {
    
    /* 
        Nota: Si hay un sólo mediador concreto, no es 
        necesario que haya un interfaz de Mediador separada.       
    */
    
    public void registrarColega(Colega colega);
    
    public void desconectarColega(Colega colega);
    
    public void infomarPedidoNuevo(Pedido pedido);
    
    public void tomarPedido(Pedido pedido);
    
}
