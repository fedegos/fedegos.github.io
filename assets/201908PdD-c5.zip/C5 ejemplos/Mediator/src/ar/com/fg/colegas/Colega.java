/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.colegas;

import ar.com.fg.mediador.Mediador;
import ar.com.fg.pedidos.Pedido;
import java.util.List;

/**
 *
 * @author Federico
 */
public interface Colega {
    
    public void setMediador(Mediador mediador);    
    public void nuevoPedido(Pedido pedido);
    public void pedidoTomado(Pedido pedido);
    public List<Pedido> getPedidosPendientes();
}

