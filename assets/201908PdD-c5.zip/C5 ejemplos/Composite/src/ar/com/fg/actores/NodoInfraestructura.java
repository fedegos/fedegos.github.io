/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Federico
 */
public abstract class NodoInfraestructura implements ComponenteRedElectrica {

    private List<ComponenteRedElectrica> hijos = new ArrayList<>();

    public void agregarComponente(ComponenteRedElectrica componente) {
        hijos.add(componente);
    }

    /**
     *
     */
    public void desconectar() {
        for (ComponenteRedElectrica componente : hijos) {
            componente.desconectar();
        }
    }

    @Override
    public void conectar() {
        for (ComponenteRedElectrica componente : hijos) {
            componente.conectar();
        }
    }

}
