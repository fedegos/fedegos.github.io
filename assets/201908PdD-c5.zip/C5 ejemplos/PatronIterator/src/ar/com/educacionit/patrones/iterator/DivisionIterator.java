package ar.com.educacionit.patrones.iterator;

import java.util.Iterator;

public class DivisionIterator implements Iterator<Empleado> {

    private Empleado[] empleados;
    private int location = 0;    

    public DivisionIterator(Empleado[] e) {
        empleados = e;
    }

    @Override
    public Empleado next() {        
        return empleados[location++];        
    }

    @Override
    public boolean hasNext() {
        if (location < empleados.length && empleados[location] != null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void remove() {
    }
}
