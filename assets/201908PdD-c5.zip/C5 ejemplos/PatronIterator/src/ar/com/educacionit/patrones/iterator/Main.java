package ar.com.educacionit.patrones.iterator;

import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        // Implementar un iterador que devuelva los items pares.
        
        Division division = new Division("Mi Sucursal");
        division.add("Juan");
        division.add("Pedro");

        DivisionIterator iter = division.miIterador();
        while (iter.hasNext()) {
            Empleado empleado = (Empleado) iter.next();
            empleado.print();
        }
    }
}
