package ar.com.educacionit.patrones.composite;

public class Aula extends Composite {
}