var edad = prompt("ingrese su edad", 21);
alert(edad);

var confirmado = confirm("¿Está seguro?");
alert(confirmado);

