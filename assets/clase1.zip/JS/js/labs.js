var x = 10;
var y = 20;

x = x + x + 1;
y = y - y - x;

alert("El valor de x es " + x);
alert("El valor de y es " + y);