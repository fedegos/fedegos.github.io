package ar.com.educacionit.patrones.chain.impl;

import ar.com.educacionit.patrones.chain.IAprobador;

public class Banco implements IAprobador {

    private IAprobador next;
    
    public Banco() {
        EjecutivoDeCuenta ejecutivo = new EjecutivoDeCuenta();
        this.setNext(ejecutivo);
    }

    @Override
    public IAprobador getNext() {
        return next;
    }

    @Override
    public void solicitudPrestamo(int monto) {
        next.solicitudPrestamo(monto);
    }

    @Override
    public void setNext(IAprobador aprobador) {
        next = aprobador;
    }
}
