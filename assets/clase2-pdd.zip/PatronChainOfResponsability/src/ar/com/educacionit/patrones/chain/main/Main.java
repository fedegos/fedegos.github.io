package ar.com.educacionit.patrones.chain.main;

import ar.com.educacionit.patrones.chain.impl.Banco;

public class Main {
    public static void main(String[] args) {
        Banco banco = new Banco();
        banco.solicitudPrestamo(56000);
        
        banco.solicitudPrestamo(1000);
        
        banco.solicitudPrestamo(444000);
        
        banco.solicitudPrestamo(25000);
    }
}
