/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.receivers;

/**
 *
 * @author Federico
 */
public class Luz {
    
    public void prender() {
        System.out.println("Luz prendida");
    }
    
    public void apagar() {
        System.out.println("Luz apagada");
    }
    
    
}
