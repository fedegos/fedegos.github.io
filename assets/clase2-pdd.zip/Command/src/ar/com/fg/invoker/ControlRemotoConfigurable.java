/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.invoker;

import ar.com.fg.actores.Command;
import java.util.HashMap;

/**
 *
 * @author Federico
 */
public class ControlRemotoConfigurable {
    
    private HashMap<String, Command> comandos = new HashMap<String, Command>();
    
    public void configurarBoton(String color, Command comando) {
        comandos.put(color, comando);
    }
    
    public void apretarBoton(String color) {
        comandos.get(color).ejecutar();
    }
    
    
}
