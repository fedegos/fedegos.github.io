/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.comandos;

import ar.com.fg.actores.Command;
import ar.com.fg.receivers.Luz;

/**
 *
 * @author Federico
 */
public class ApagarLuz implements Command {

    private Luz luz;
        
    public ApagarLuz(Luz luz) {
        this.luz = luz;
    }
    
    @Override
    public void ejecutar() {
        luz.apagar();
    }
    
    @Override
    public void deshacer() {
        luz.prender();
    }
    
}
