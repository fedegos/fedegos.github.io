/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.comandos;

import ar.com.fg.actores.Command;

/**
 *
 * @author EducaciónIT
 */
public class PrenderTodasLasLuces implements Command {

    private Command comando1;
    private Command comando2;
    
    public PrenderTodasLasLuces(Command comando1, Command comando2) {
        this.comando1 = comando1;
        this.comando2 = comando2;
    }
    
    @Override
    public void ejecutar() {
        comando1.ejecutar();
        comando2.ejecutar();        
    }

    @Override
    public void deshacer() {
        comando1.deshacer();
        comando2.deshacer();        
    }
          
    
    
}
