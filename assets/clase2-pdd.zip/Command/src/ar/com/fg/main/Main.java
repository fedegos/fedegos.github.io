/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.actores.Command;
import ar.com.fg.comandos.ApagarLuz;
import ar.com.fg.comandos.PrenderLuz;
import ar.com.fg.comandos.PrenderTodasLasLuces;
import ar.com.fg.invoker.ControlRemotoConfigurable;
import ar.com.fg.receivers.Luz;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Ejercicios
        // Agregar un comando alternar
        // Agregar un invoker nuevo con al menos un comando.
        // Crear una macro con múltiples luces: prender todas (hay que agregar 
        // getter de estado)
        
        
        Luz velador = new Luz();
        
        /*
        Command prender = new PrenderLuz(velador);
        ControlRemoto controlSimple = new ControlRemoto(prender);
        
        Command apagar = new ApagarLuz(velador);
        
        ControlRemoto controlParaApagar = new ControlRemoto(apagar);
        
        controlSimple.apretarBoton();
        controlSimple.deshacerComando();
        */
        
        // controlSimple.apretarBoton();
        // controlParaApagar.apretarBoton();
        
        Luz luzPrincipalHabitacion = new Luz();
        Command prenderLuzPrincipal = new PrenderLuz(luzPrincipalHabitacion);
        Command apagarLuzPrincipal = new ApagarLuz(luzPrincipalHabitacion);
        
        ControlRemotoConfigurable control = new ControlRemotoConfigurable();
        Command prender = new PrenderLuz(velador);
        Command apagar = new ApagarLuz(velador);
        
        Command prenderTodo = new PrenderTodasLasLuces(prender, prenderLuzPrincipal);
        
        control.configurarBoton("verde", prender);
        control.configurarBoton("rojo", apagar);
        
        control.configurarBoton("azul", prenderLuzPrincipal);
        control.configurarBoton("violeta", apagarLuzPrincipal);
        
        control.configurarBoton("naranja", prenderTodo);
        
        control.apretarBoton("naranja");
     
    }
    
}
