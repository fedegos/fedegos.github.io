/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.actores.Facebook;
import ar.com.fg.actores.Linkedin;
import ar.com.fg.actores.RedSocial;
import ar.com.fg.actores.Twitter;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
            Ejercicios
            1. Agregar una red social (por ejemplo, Linkedin)
            2. Agregar un paso de "compartir" al template method. 
               Ajustar la implementación de las redes sociales en 
               consecuencia.
        */
        
        RedSocial twitter = new Twitter("@fede", "miclave");
        RedSocial facebook = new Facebook("Federico", "miclavefb");
        RedSocial linkedin = new Linkedin();

        twitter.postear("Hola twitter!!!");
        facebook.postear("Miren... gatitos!!!");        
        linkedin.postear("Este sitio es más serio.");
        
    }
    
}
