/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author EducaciónIT
 */
public class Linkedin extends RedSocial {

    @Override
    protected boolean login() {
        System.out.println("Entrando a Linkedin");
        return true;
    }

    @Override
    protected void enviarDatos(String mensaje) {
        System.out.println("Enviando en Linkedin el mensaje: " + mensaje);
    }

    @Override
    protected void logout() {
        System.out.println("Saliendo de Linkedin");
    }

    @Override
    protected void compartir(String mensaje) {
        System.out.println("Compartiendo el mensaje en Linkedin");
    }
    
}
