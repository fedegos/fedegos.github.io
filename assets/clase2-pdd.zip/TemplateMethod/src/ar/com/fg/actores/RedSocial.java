/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author Federico
 */
public abstract class RedSocial {
    
    public boolean postear(String mensaje) {
        if (login()) {
            enviarDatos(mensaje);
            compartir(mensaje);
            logout();
            return true;
        }
        return false;
    }
        
    abstract protected boolean login();
    abstract protected void enviarDatos(String mensaje);
    abstract protected void compartir(String mensaje);
    abstract protected void logout();
    
}
