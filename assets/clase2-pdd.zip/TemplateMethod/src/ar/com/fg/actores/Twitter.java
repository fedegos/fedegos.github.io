/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.actores;

/**
 *
 * @author Federico
 */
public class Twitter extends RedSocial {
    private String usuario;
    private String clave;
    
    public Twitter(String usuario, String clave) {
        this.usuario = usuario;
        this.clave = clave;
    }

    @Override
    protected boolean login() {
        System.out.println(String.format("Accediendo a Twitter con usuario %s y clave %s", usuario, clave));
        return true;
    }

    @Override
    protected void enviarDatos(String mensaje) {
        System.out.println("Posteando en Twitter: " + mensaje);
    }

    @Override
    protected void logout() {
        System.out.println("Cerrando Twitter");
    }        

    @Override
    protected void compartir(String mensaje) {
        System.out.println("Compartiendo el mensaje en Twitter");
    }
    
}

