/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.legacy;

/**
 *
 * @author Federico
 */
public class Archivo {
    
    public Archivo(String nombreArchivo) {
        System.out.println("Obteniendo archivo " + nombreArchivo);
    }
    
}
