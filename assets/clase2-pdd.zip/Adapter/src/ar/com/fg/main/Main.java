/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.main;

import ar.com.fg.adapter.AdaptadorVentaPedido;
import ar.com.fg.ecommerce.Venta;
import ar.com.fg.sistemalogistico.Envio;

/**
 *
 * @author Federico
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* 
        Ejercicios
            1. Cambiar la implementación en Venta del cliente y separar en 
                getNombre y getApellido. Ajustar el adaptador.
            2. Si aparece una nueva clase de Venta (VentaTelefonica) con una 
               interfaz distinta a la de Venta de ecommerce, ¿Puedo reusar el 
               mismo adaptador?
        */
        
        Venta venta = new Venta(); // viene del Ecommerce
        AdaptadorVentaPedido pedido = new AdaptadorVentaPedido(venta); 
        
        Envio envio = new Envio();
        int costo = envio.calcularCosto(pedido);
        
        System.out.println("El costo es: " + costo);
    }
    
}
