/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.adapter;

import ar.com.fg.ecommerce.Venta;
import ar.com.fg.sistemalogistico.Pedido;

/**
 *
 * @author Federico
 */
public class AdaptadorVentaPedido implements Pedido{
    private Venta venta;
    
    public AdaptadorVentaPedido(Venta venta) {
        this.venta = venta;
    }

    @Override
    public String direccionDestino() {
        return venta.getDireccion();
    }

    @Override
    public int pesoTotal() {
        return venta.getPesoUnitario() * venta.getUnidades();
    }

    @Override
    public String nombreCliente() {
        return venta.nombreCliente() + venta.apellidoCliente();
    }
    
}
