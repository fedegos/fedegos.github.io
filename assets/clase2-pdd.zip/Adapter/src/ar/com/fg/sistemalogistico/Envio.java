/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.sistemalogistico;

/**
 *
 * @author Federico
 */
public class Envio {
    /*
        Esta clase es el cliente que espera la interfaz 
        Target (pedido) para aplicar su lógica.
    */
    
    public int calcularCosto(Pedido pedido) {
        System.out.println("Dirección: " + pedido.direccionDestino());
        System.out.println("Peso total: " + pedido.pesoTotal());
        
        return 55;        
    }
    
}
