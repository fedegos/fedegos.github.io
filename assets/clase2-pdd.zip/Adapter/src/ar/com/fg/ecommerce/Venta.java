/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.fg.ecommerce;

/**
 *
 * @author Federico
 */
public class Venta {
    
    public String nombreCliente() {
        return "Nombre del cliente";
    }
    
    public String apellidoCliente() {
        return "Apellido del cliente";
    }
    
    public String getProducto() {
        return "Nombre del producto";
    }
    
    public int getPesoUnitario() {
        return 24;
    }
    
    public int getUnidades() {
        return 5;
    }
    
    public String getDireccion() {
        return "Lavalle 648, CABA, Argentina.";
    }
}
