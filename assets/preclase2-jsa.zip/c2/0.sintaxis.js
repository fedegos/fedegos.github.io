// Definición de eventos

const boton = document.querySelector("button");

// con función anónima
boton.onclick = function() { console.log("click"); }

// asignando función con nombre
function foo() { 
    console.log("click");    
}

boton.onclick = foo; // notar que no es foo();

// La función para agregar un listener tiene la siguiente forma:
// target.addEventListener(evento, funcionListener [, operarDuranteFaseCaptura])

boton.addEventListener("click", foo);

/* 
Como siempre que puedo usar una referencia de función como 
parámetro en una llamada, también puedo usar una función anónima.
*/

boton.addEventListener("click", function() {
    console.log("click");
});


// Sin embargo, cuando uso una función anónima no puedo remover el listener. 
// Las funciones nombradas pueden ser removidas de un evento con removeEventListener:
boton.removeEventListener("click", foo);


// objeto event 

function foo (evento)  {
    console.log(evento.clientX);
}

/*
Al asociar foo a un evento de Mouse como 'click', el parámetro 
que recibirá la función listener 'foo' es del tipo MouseEvent.
 */
boton.addEventListener("click", foo); 

// Propiedades del MouseEvent: https://developer.mozilla.org/es/docs/Web/API/MouseEvent

// El objeto evento tiene las propiedades target, que es el destinatario original del evento,  
// y currentTarget, que es el objeto que recive el evento en las fases capturing y bubbling.
event.target;

event.currentTarget;

// Podemos usar stopPropagation() para evitar que el evento se propague a los siguientes listener.
event.stopPropagation();

// Podemos usar preventDefault() para evitar que un objeto tenga su comportamiento normal ante una acción.
event.preventDefault();