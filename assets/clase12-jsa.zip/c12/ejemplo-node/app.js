const http = require("http");

let host = "127.0.0.1";
let port = 3000;

const server = http.createServer((request, response) => {
    console.log(request.url);
    response.statusCode = 200;
    response.setHeader("Content-Type", "text/plain");
    response.end("Hola desde Node!!!");    
});

server.listen(port, host, () => {
    console.log(`Servidor listo en http://${host}:${port}/`);
});