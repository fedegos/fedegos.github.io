const greeting = () => "Hello World"

console.log(Math.max(...[1,2,3]))

let a = [4,5]
let [b, c] = a