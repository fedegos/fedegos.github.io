export default function printMe() {
    console.log('Esto es JavaScript!'); // Acá está el error
}