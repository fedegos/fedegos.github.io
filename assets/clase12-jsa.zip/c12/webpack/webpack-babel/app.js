const greetings = () => { console.log("Bienvenidos!") }

greetings();