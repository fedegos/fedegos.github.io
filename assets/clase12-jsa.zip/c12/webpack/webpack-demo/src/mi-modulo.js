module.exports = function() {
    console.log("Saludos desde mi módulo!")
}